﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TestWebApi.Models;

namespace TestWebApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AppointmentController : ControllerBase
    {

        private readonly IAppointmentRepository _AppointmentRepository;

        public AppointmentController(IAppointmentRepository repository)
        {
            _AppointmentRepository = repository;

        }

        [HttpGet]
        public Appointment Get()
        {
            var Appointment = _AppointmentRepository.GetAppointment(1);

            return Appointment;
        }

        [HttpPost]
        public bool Create([FromBody] Appointment Appointment)
        {
            if (ModelState.IsValid)
            {
                return _AppointmentRepository.Add(Appointment);
            }
            return false;
        }

        [HttpGet]
        [Route("api/Appointments/Details/{id}")]
        public Appointment Details(int id)
        {
            var Appointment = _AppointmentRepository.GetAppointment(id);

            return Appointment;
        }

        [HttpPut]
        [Route("api/Appointments/Edit")]
        public bool Edit([FromBody] Appointment Appointment)
        {
            if (ModelState.IsValid)
            {
                return _AppointmentRepository.Update(Appointment);
            }
            return false;
        }

        [HttpDelete]
        public bool DeleteConfirmed(int id)
        {
            return _AppointmentRepository.Delete(id);
        }
    }
}
