﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using TestWebApi.Models;

namespace TestWebApi.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class PatientController : ControllerBase
    {

        private readonly IPatientRepository _patientRepository;

        public PatientController(IPatientRepository repository)
        {
            _patientRepository = repository;

        }

        [HttpGet]
        public List<Patient> Get()
        {
            return  _patientRepository.GetPatient(1).ToList();

           // return patient;
        }
        
        [HttpPost]

        public IActionResult Create([FromBody] Patient patient)
            {
            if (ModelState.IsValid)
            {
                try
                {
                    return Ok(_patientRepository.Add(patient));
                }
                catch (Exception ex)
                {
                    return BadRequest($"Failed to create Patient Record {ex.InnerException.Message}" );
                }

                
            }
            return BadRequest("Failed to create Patient Record, due to Invalid Model"); 
        }

        [HttpGet]
        [Route("api/Patients/Details/{id}")]
        public List<Patient> Details(int id)
        {

           
            return  _patientRepository.GetOnePatient(id).ToList();

        }

        [HttpGet]
        [Route("api/Patients/UserInfo")]
        public string UserInfo()
        {

            return Request.Headers["User-Agent"].ToString();

        }


        [HttpPut]
        [Route("api/Patients/Edit")]
        public IActionResult Edit([FromBody] Patient patient)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    return Ok( _patientRepository.Update(patient));
                }
                catch (Exception ex)
                {
                    return BadRequest($"Failed to Update Patient Record {ex.Message}");
                }


            }
            return BadRequest("Failed to update Patient Record, due to Invalid Model");
            
        }

        [HttpDelete]
        public IActionResult DeleteConfirmed(int id)
        {
            
            try
            {
                return Ok(_patientRepository.Delete(id));
            }
            catch (Exception ex)
            {
                return BadRequest($"Failed to delete Patient Record {ex.InnerException.Message}");
            }


        }
    }

}

