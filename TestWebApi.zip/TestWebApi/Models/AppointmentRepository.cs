﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TestWebApi.Models
{
    public class AppointmentRepository : IAppointmentRepository
    {

        private readonly SqlDbContext db;


        public AppointmentRepository(SqlDbContext ctx)
        {
            db = ctx;

        }
        public bool Add(Appointment Appointment)
        {

            db.Add(Appointment);
            return db.SaveChanges() > 0;


        }
        public bool Update(Appointment Appointment)
        {
            db.Entry(Appointment).State = EntityState.Modified;
            return db.SaveChanges() > 0;


        }
        public bool Delete(int id)
        {
            Appointment Appointment = db.Appointments.Find(id);
            db.Appointments.Remove(Appointment);
            return db.SaveChanges() > 0;



        }
        public Appointment GetAppointment(int id)
        {
            Appointment Appointment = db.Appointments.Find(id);
            if (Appointment == null)
            {
                return null;
            }
            return Appointment;

        }
    }
}
