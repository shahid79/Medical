﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestWebApi.Models
{
    public interface IPatientRepository
    {
       public bool Add(Patient patient);
       public bool Update(Patient patient);
       public bool Delete(int id);
       public IEnumerable<Patient> GetPatient(int id);
        public IEnumerable<Patient> GetOnePatient(int id);
    }
}
