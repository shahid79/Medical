﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TestWebApi.Models
{
    public interface  IAppointmentRepository
    {
        public bool Add(Appointment appointment);
        public bool Update(Appointment appointment);
        public bool Delete(int id);
        public Appointment GetAppointment(int id);
    }
}
