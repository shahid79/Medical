﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace TestWebApi.Models
{
    public class PatientRepository : IPatientRepository
    {
        
        private readonly SqlDbContext db;
        

        public PatientRepository(SqlDbContext ctx)
        {
            db = ctx;
            
        }
        public bool Add(Patient patient)
        {

            db.Add(patient);
            return db.SaveChanges() > 0;


        }
        public bool Update(Patient patient)
        {
            try
            {
                db.Entry(patient).State = EntityState.Modified;
                return db.SaveChanges() > 0;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public bool Delete(int id)
        {
            Patient patient = db.Patients.Find(id);
            db.Patients.Remove(patient);
            return db.SaveChanges() > 0;



        }
        public IEnumerable<Patient> GetPatient(int id)
        {
            return db.Patients
                    .Include(a => a.appointments).ToList();
            /*
               ;
            if (patient == null)
            {
                return null;
            }
            return patient;
            */
        }

        public IEnumerable<Patient> GetOnePatient(int id)
        {
             
                
                return db.Patients
                    .Where(o => o.Id == id).ToList();

            
            /*
               ;

            if (patient == null)
            {
                return null;
            }
            return patient;
            */
        }


    }
}
