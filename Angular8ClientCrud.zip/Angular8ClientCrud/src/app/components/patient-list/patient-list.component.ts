import { Component, OnInit } from '@angular/core';
import { patientService } from 'src/app/services/patient.service';
declare const myTest: any;


@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit {

  patient: any;
  currentpatient = null;
  currentIndex = -1;
  fisrtName = '';

  constructor(private patientService: patientService) { }

  ngOnInit() {
    //myTest();
    this.retrievePatient();
  }

  retrievePatient() {
    this.patientService.getAll()
      .subscribe(
        data => {
          this.patient = data;
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  refreshList() {
    this.retrievePatient();
    this.currentpatient = null;
    this.currentIndex = -1;
  }

  setActivePatient(patient, index) {
    
    this.currentpatient = patient;
    this.currentIndex = index;
  }


  
}