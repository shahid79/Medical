import { Component, OnInit } from '@angular/core';
import { patientService } from 'src/app/services/patient.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css']
})
export class PatientDetailsComponent implements OnInit {
  currentPatient = null;
  message = '';

  constructor(
    private patientService: patientService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.message = '';
    this.getPatient(this.route.snapshot.paramMap.get('id'));
  }

  getPatient(id) {
    this.patientService.get(id)
      .subscribe(
        data => {
          this.currentPatient = data[0];
          console.log(data);
        },
        error => {
          console.log(error);
        });
  }

  
  updatePatient() {
    this.patientService.update(this.currentPatient.id, this.currentPatient)
      .subscribe(
        response => {
          console.log(response);
          this.message = 'The patient was updated successfully!';
        },
        error => {
          console.log(error);
        });
  }

  deletePatient() {
    this.patientService.delete(this.currentPatient.id)
      .subscribe(
        response => {
          console.log(response);
          this.router.navigate(['/patients']);
        },
        error => {
          console.log(error);
        });
  }
}