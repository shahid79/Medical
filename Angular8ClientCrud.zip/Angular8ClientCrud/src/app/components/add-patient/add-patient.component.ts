import { Component, OnInit } from '@angular/core';
import { patientService } from 'src/app/services/patient.service';

@Component({
  selector: 'app-add-patient',
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.css']
})
export class AddPatientComponent implements OnInit {
  patient = {
    firstName:'',
    dateOfBirth: '',
    lastName: ''
  };
  submitted = false;

  constructor(private patientService: patientService) { }

  ngOnInit() {
  }

  savePatient() {
    const data = {
      lastName: this.patient.lastName,
      firstName: this.patient.firstName,
      dateOfBirth: this.patient.dateOfBirth
    };

    this.patientService.create(data)
      .subscribe(
        response => {
          console.log(response);
          this.submitted = true;
        },
        error => {
          console.log(error);
        });
  }

  newPatient() {
    this.submitted = false;
    this.patient = {
      firstName: '',
      lastName: '',
      dateOfBirth: ''
    };
  }
}