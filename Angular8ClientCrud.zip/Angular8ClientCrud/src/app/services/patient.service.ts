import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


const baseUrl = 'http://localhost:5000/Patient';

@Injectable({
  providedIn: 'root'
})
export class patientService {

  constructor(private http: HttpClient) { }

  getAll() {
    return this.http.get(baseUrl);
  }

  
  get(id) {
    return this.http.get(`${baseUrl}/api/Patients/Details/${id}`);
  }

  create(data) {

    //let headers = new Headers({
    //  'Content-Type':'application/json; charset=utf-8;' 
    //  ,'Accept':'*/*', Access-Control-Allow-Origin: *
   // });
   // const options =  ({
   //   headers: headers
   // });
  
    
    return this.http.post(baseUrl, data, {
      headers : new HttpHeaders().set("Access-Control-Allow-Origin", "*" )
                                .set('content-type', 'application/json')
                                .set('Accept', '*/*')
              });
  }

  update(id, data) {
    return this.http.put(`${baseUrl}/api/Patients/Edit`, data);
  }

  delete(id) {
    return this.http.delete(`${baseUrl}?id=${id}`);
  }


}