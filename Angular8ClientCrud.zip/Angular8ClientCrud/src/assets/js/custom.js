function myTest(){
alert('hi');
   }
    